local x

local function g()
	local a, b, c
	return a, b, c
end

local function f()
	print("hello")
end

g()
x = ...

f()
