t = true
f = false
n = nil
s = "Hello"
z = 0
one = 1

print(t)
print(f)

print(not t)
print(not f)
print(not n)
print(not z)
print(not s)
print(not(not(t)))
print(not(not(z)))
print(not(not(n)))

print(t and f)
print(t or f)
print(f and t)
print(f or t)

print(f or one)
print(f or z)
print(f or n)

print(t and one)
print(t and z)
print(t and n)
