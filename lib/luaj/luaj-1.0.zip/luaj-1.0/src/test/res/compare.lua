if 2 < 5 then
	print("OK!")
else
	print("Something is not right")
end

print(2 < 5)
print(2 <= 5)
print(2 == 5)
print(2 ~= 5)
print(2 > 5)
print(2 >= 5)
